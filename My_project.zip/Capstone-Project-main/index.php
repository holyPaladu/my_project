<?php include "layouts/header.php"; ?>
<div class="container">

<center><h2 style="color:black; margin-top:20%">Cybersecurity Capstone Project by Felipe Canales Cayuqueo</h2></center>
<center><a href="https://github.com/FelipeCC24/Cybersecurity-Capstone-Project"><img src="images/logo.png" width="180" height="60"></a></center>
</div>

</body>
</html>
