<?php


$dbHost ='remotemysql.com';
$dbUsername ='5AEawBMs48';
$dbPassword ='SwE7zrSYhS';
$dbDatabase ='5AEawBMs48';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);


/*
$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='proyect_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);
*/


?>